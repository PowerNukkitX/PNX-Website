图片中所示的配置信息您可在Nukkit.yml中和Server.properties中找到，
但使用前提为您下载了terra分支的构建版本


The configuration information shown in the image can be found in Nukkit.yml and in Server.properties.
But only if you have downloaded the build version of the terra branch